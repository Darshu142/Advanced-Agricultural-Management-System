# Agritech

![image](https://github.com/MainakRepositor/Agritech/assets/64016811/bc55dbdb-2a9a-4ec2-abb6-6b1ff09f7733)

